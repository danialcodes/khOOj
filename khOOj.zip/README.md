# khOOj - by Danial
A bangladeshi pwned checker
