        <nav class="navbar navbar-expand-lg navbar-dark bg-primary ">
            
            <a class="navbar-brand" href="#">Navbar</a>
        
            <div class="collapse navbar-collapse justify-content-end" id="">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Search</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Sign in</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Me</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">How it works</a>
                    </li>
                </ul>
            </div>
        </nav>